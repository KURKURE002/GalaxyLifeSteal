import os
import discord

intents = discord.Intents.default()
intents.members = True
intents.message_content = True

client = discord.Client(intents=intents)

# Bot owner's user ID
owner_id = 1156166613729542185  # Replace with your actual owner ID

# Dictionary to store command information
commands_info = {
    "$hello": "Say hello!",
    "$kick": "Kick a member.",
    "$ban": "Ban a member.",
    "$unban": "Unban a member.",
    "$addrole": "Add a role to a member.",
    "$removerole": "Remove a role from a member.",
    "$say": "Make the bot say something."
}

# Help command
async def help_command(message):
    help_embed = discord.Embed(title="Bot Commands", color=0xFF5733)
    for command, description in commands_info.items():
        help_embed.add_field(name=command, value=description, inline=False)
    await message.channel.send(embed=help_embed)

# Function to send a welcome message via DM
async def send_welcome_message(member):
    embed = discord.Embed(
        title=f"Welcome to the server {member.display_name}!",
        description="We're glad to have you with us.",
        color=0xE91E63
    )
    embed.add_field(name="Rules", value="Be kind and respectful to others.")
    embed.set_footer(text="Enjoy your stay!")
    try:
        await member.send(embed=embed)
    except discord.HTTPException:
        print("Failed to send welcome message to", member.display_name)

@client.event
async def on_ready():
    await client.change_presence(activity=discord.Game(name="Playing Kurkure Lifesteal"))
    print('We have logged in as {0.user}'.format(client))

@client.event
async def on_message(message):
    if message.author == client.user:
        return

    # Add your existing command handlers here
    # Report command
    if message.content.startswith('$report'):
        # Split the message content to extract reported user and reason
        parts = message.content.split(' ', 2)
        if len(parts) < 3:
            await message.channel.send("Usage: $report <user_mention> <reason>")
            return

        reported_user = parts[1]
        reason = parts[2]

        # Get the bot owner
        owner = await client.fetch_user(owner_id)

        # Send a direct message to the bot owner as an embed
        report_embed = discord.Embed(
            title="REPORT \n",
            description=f"User {message.author} reported {reported_user} \n \n reason: {reason}.",
            color=0xFF69B4
        )
        await owner.send(embed=report_embed)

        await message.channel.send("Report has been sent to the OWNER.")
        return

    # Add help command
    if message.content.startswith('$help'):
        await help_command(message)
        return

    # Hello command
    if message.content == '$hello':
        await message.channel.send("Hello! How are you today?")

    # Command to kick a member
    if message.content.startswith('$kick'):
        if message.author.guild_permissions.kick_members:
            if len(message.mentions) > 0:
                member = message.mentions[0]
                await member.kick(reason="Kicked by {}".format(message.author))
                await message.channel.send(f'{member.display_name} has been kicked.')
            else:
                await message.channel.send('Please mention the user to kick.')
        else:
            await message.channel.send('You do not have permission to kick members.')

    # Command to ban a member
    if message.content.startswith('$ban'):
        if message.author.guild_permissions.ban_members:
            if len(message.mentions) > 0:
                member = message.mentions[0]
                await member.ban(reason="Banned by {}".format(message.author))
                await message.channel.send(f'{member.display_name} has been banned.')
            else:
                await message.channel.send('Please mention the user to ban.')
        else:
            await message.channel.send('You do not have permission to ban members.')

    # Command to unban a member
    if message.content.startswith('$unban'):
        if message.author.guild_permissions.ban_members:
            if len(message.content.split()) == 2:
                banned_user = await client.fetch_user(int(message.content.split()[1]))
                if banned_user:
                    await message.guild.unban(banned_user)
                    await message.channel.send(f'{banned_user} has been unbanned.')
                else:
                    await message.channel.send('User not found. Please provide a valid user ID.')
            else:
                await message.channel.send('Please provide the user ID to unban.')
        else:
            await message.channel.send('You do not have permission to unban members.')

    # Command to add a role to a member
    if message.content.startswith('$addrole'):
        if message.author.guild_permissions.manage_roles:
            try:
                role_name = message.content.split()[1]
                role = discord.utils.get(message.guild.roles, name=role_name)
                if role:
                    if len(message.mentions) > 0:
                        member = message.mentions[0]
                        await member.add_roles(role)
                        await message.channel.send(f'{role.name} role has been added to {member.display_name}.')
                    else:
                        await message.channel.send('Please mention the user to add the role.')
                else:
                    await message.channel.send('Role not found.')
            except IndexError:
                await message.channel.send('Please provide the role name to add.')
        else:
            await message.channel.send('You do not have permission to manage roles.')

    # Command to remove a role from a member
    if message.content.startswith('$removerole'):
        if message.author.guild_permissions.manage_roles:
            try:
                role_name = message.content.split()[1]
                role = discord.utils.get(message.guild.roles, name=role_name)
                if role:
                    if len(message.mentions) > 0:
                        member = message.mentions[0]
                        await member.remove_roles(role)
                        await message.channel.send(f'{role.name} role has been removed from {member.display_name}.')
                    else:
                        await message.channel.send('Please mention the user to remove the role from.')
                else:
                    await message.channel.send('Role not found.')
            except IndexError:
                await message.channel.send('Please provide the role name to remove.')
        else:
            await message.channel.send('You do not have permission to manage roles.')

    # Command to make the bot say something
    if message.content.startswith('$say'):
        # Check if the user has permission to use this command
        if message.author.guild_permissions.manage_messages:
            # Extract the text to say
            text = message.content[len('$say'):].strip()
            if text:
                # Send the provided text
                await message.channel.send(text)
            else:
                await message.channel.send("Please provide text for me to say!")
        else:
            await message.channel.send("You do not have permission to use this command.")

@client.event
async def on_member_join(member):
    await send_welcome_message(member)

try:
    token = os.getenv("TOKEN") or ""
    if token == "":
        raise Exception("Please add your token to the Secrets pane.")
    client.run(token)
except discord.HTTPException as e:
    if e.status == 429:
        print("The Discord servers denied the connection for making too many requests")
        print("Get help from Kurkure")
    else:
        raise e